Fixed sleig , you need to replace gameserver.js and handler/worldupdate/check/normalplayercheck.js with the new ones.
i have added an auto advertising.
Infinity ability added , replace game.js and playergameplay/abilitiesswitch.js
